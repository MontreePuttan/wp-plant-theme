<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
echo do_shortcode('[smartslider3 slider=' . $settings->sliderid . ']');